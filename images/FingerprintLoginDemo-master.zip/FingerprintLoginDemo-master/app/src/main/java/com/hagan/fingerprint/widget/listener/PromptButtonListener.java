package com.hagan.fingerprint.widget.listener;

import com.hagan.fingerprint.widget.PromptButton;

/**
 * Created by FengTing on 2017/5/8.
 * https://www.github.com/limxing
 */

public interface PromptButtonListener {
    void onClick(PromptButton button);
}
