package com.hagan.fingerprint.widget.listener;

/**
 * Created by FengTing on 2017/5/23.
 * https://www.github.com/limxing
 */

public interface OnAdClickListener {
    void onAdClick();
}
