# FingerprintLoginDemo
指纹登录-功能:检测设备是否支持;指纹验证失败后错误提示;支持检测系统指纹库发生变化后需重新录入指纹功能.

1.密码登录/指纹登录 切换

![密码/指纹登录](https://github.com/haganWu/FingerprintLoginDemo/blob/master/screenshots/device-2019-01-29-163419.jpg)

![密码/指纹登录](https://github.com/haganWu/FingerprintLoginDemo/blob/master/screenshots/device-2019-01-29-155313.png)

               
               
               

2.检测设备是否支持指纹验证

![是否支持](https://github.com/haganWu/FingerprintLoginDemo/blob/master/screenshots/device-2019-01-29-154824.png)





3.指纹验证失败后错误提示

![错误提示](https://github.com/haganWu/FingerprintLoginDemo/blob/master/screenshots/device-2019-01-29-155053.png)

![错误提示](https://github.com/haganWu/FingerprintLoginDemo/blob/master/screenshots/device-2019-01-29-155104.png)





4.关闭指纹登录

![关闭指纹登录](https://github.com/haganWu/FingerprintLoginDemo/blob/master/screenshots/device-2019-01-29-155040.png)





5.系统指纹库发生变化

![系统指纹库发生变化](https://github.com/haganWu/FingerprintLoginDemo/blob/master/screenshots/device-2019-01-29-155158.png)


**(如有缺陷望指正!!!)**
