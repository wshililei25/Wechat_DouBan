# WeChat-App-Store-UI
逐步将部分工作整理而成的微信小程序商城模版

## JSDoc注释文档生成
命令行输入

```shell
jsdoc -c conf.json
```
## weui模版控件参考
https://github.com/weui/weui-wxss
