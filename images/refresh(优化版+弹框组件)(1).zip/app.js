//app.js
var successObj = null
App({
  onLaunch: function () {
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              // 可以将 res 发送给后台解码出 unionId
              this.globalData.userInfo = res.userInfo

              // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
              // 所以此处加入 callback 以防止这种情况
              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            }
          })
        }
      }
    })
  },
  showloadingMask: function (obj) {
    var that = this
    if (obj) {
      var showloadingMask;
      var showloadingTitle = '';
      var pathImg_xsw = '/component/img/loading_one.gif';
      var path = '';
      var duration = null;
      if (obj.showloadingMask)
        showloadingMask = obj.showloadingMask
      if (obj.showloadingTitle)
        showloadingTitle = obj.showloadingTitle
      if (obj.success)
        var success = obj.success
      if (obj.path)
        path = obj.path
      if (obj.pathImg_xsw)
        pathImg_xsw = obj.pathImg_xsw
      if (obj.duration)
        duration = obj.duration
      // console.log(showloadingMask)
      var pages = getCurrentPages();
      if (path == '') {
        var thisPage = pages[pages.length - 1]
      }
      else {
        thisPage = path
      }
      if (thisPage) {
        thisPage.setData({
          showloadingMask: showloadingMask,
          showloadingTitle: showloadingTitle,
          pathImg_xsw: pathImg_xsw
        })
        if (duration != null) {
          setTimeout(function () {
            thisPage.setData({
              showloadingMask: 'false'
            })
            if (success) {
              return success({ path: thisPage, showloadingMask: 'OK' })
            }
          }, duration)
        }
        else {
          if (success) {
            return success({ path: thisPage, showloadingMask: 'OK' })
          }
        }

      }
    }

  },
  showModal: function (obj) {
    var that = this
    if (obj) {
      var title = '提示';
      var content = '';
      var showNoCancel = false;
      var pageNoBind = false;
      var transparent = false;
      var success
      var frontColor = ''
      var backgroundColor = '';
      if (obj.frontColor)
        frontColor = obj.frontColor
      if (obj.backgroundColor)
        backgroundColor = obj.backgroundColor
      if (obj.title)
        title = obj.title
      if (obj.content)
        content = obj.content
      if (obj.showNoCancel) {
        showNoCancel = obj.showNoCancel
      }
      if (obj.pageNoBind)
        pageNoBind = obj.pageNoBind
      if (obj.transparent)
        transparent = obj.transparent
      if (obj.success)
        success = obj.success

      var pages = getCurrentPages();
      var thisPage = pages[pages.length - 1]
      if (thisPage) {
        thisPage.setData({
          xsw_title: title,
          xsw_content: content,
          xsw_showModal: true,
          xsw_showNoCancel: showNoCancel,
          xsw_pageNoBind: pageNoBind,
          xsw_transparent: transparent,
          xsw_frontColor: frontColor,
          xsw_backgroundColor: backgroundColor
        })
        if (success) {
          successObj = success
        }
      }
    }

  },
  callback: function (res) {
    return successObj(res)
  },
  globalData: {
    userInfo: null
  }
})