// component/refresh.js
var windowHeight;
var windowWidth;
var lastY = 0;
var lastHuaShu = 0;
var setTimeoutC;
var setIntervalC;
var setIntervalK;
var setTimeoutJ;
var downRefresh=true;
var enablePullDownRefresh;
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    color: {
      type: String,
      value: '#fbe8b9',
    },
    enablePullDownRefresh: {
      type: String,
      value: 'true',
    },
    code: {
      type: Number,
      value:0,
    },
    zIndex: {
      type: Number,
      value: 9,
    },
    scrollY: {
      type: Boolean,
      value: false,
    },
    scrollX: {
      type: Boolean,
      value: false,
    },
    upperThreshold: {
      type: Number,
      value: 50,
    },
    lowerThreshold: {
      type: Number,
      value: 50,
    },
    scrollTop: {
      type: Number,
      value: 0,
    },
    scrollLeft: {
      type: Number,
      value: 0,
    },
    scrollIntoView: {
      type: String,
      value: '',
    },
    scrollWithAnimation: {
      type: Boolean,
      value: false,
    },
    enableBackToTop: {
      type: Boolean,
      value: false,
    },
  },

  /**
   * 组件的初始数据
   */
  data: {
    animationDataZ: {},
    text: '下拉刷新!',
    dianNum:null,
    jiantou:true,
    catchP: true,
    scroll_Y: false,
    scroll_X: false,
    scroll_Top: 0,
    scroll_Left: 0,
    scroll_Into_View: '',
    scroll_With_Animation: false,
    enable_Back_To_Top: false,
  },
  options: {
    multipleSlots: true
  },

  /**
   * 组件的方法列表
   */
  
  created:function(){
    var that = this
    wx.getSystemInfo({
      success: function (res) {
        windowHeight = res.windowHeight
        windowWidth = res.windowWidth
      }
    })
    
  },
  ready:function(){
    var that = this
    if (that.data.enablePullDownRefresh=='false'){
      downRefresh=false
    }
    else{
      downRefresh=true
    }
    enablePullDownRefresh = that.data.enablePullDownRefresh
    // setTimeout(function(){
    //   that.setData({
    //     scroll_Top: scroll_Top,
    //     scroll_Left: scroll_Left,
    //   })
    // },10)
    that.triggerEvent('myevent', { onrefresh: false }, {})
  },

  methods: {
    toupper: function () {
      this.triggerEvent('myevent', { toupper: 'true' }, {})
    },
    tolower: function () {
      this.triggerEvent('myevent', { tolower: 'true' }, {})
     
    },
    scroll: function (e) {
      var that = this
      this.triggerEvent('myevent', { scroll: e.detail }, {})  
      if (downRefresh==true){
        if (e.detail.scrollTop > 20) {
          that.setData({
            enablePullDownRefresh: 'false'
          })
        }
        else {
          that.setData({
            enablePullDownRefresh: 'true'
          })

        }
      }
      // console.log(that.data.enablePullDownRefresh)
      

    },
    star: function (e) {
      var that = this
      clearTimeout(setTimeoutJ);
      lastY = e.touches[0].pageY
      lastHuaShu = 0
      clearTimeout(setTimeoutC);
      
      that.setData({
        jiantou:true,
      })
    },
    move: function (e) {
      var that = this
      var currentY = e.touches[0].pageY
      var animationSX = wx.createAnimation({
        transformOrigin: "50% 50%",
        duration: 0,
        timingFunction: "ease",
        delay: 0
      })
      var animationZ = wx.createAnimation({
        transformOrigin: "50% 50%",
        duration: 500,
        timingFunction: "ease",
        delay: 0
      })
      var rpx = 750 / windowWidth
      var px = windowWidth / 750
      var text = that.data.text;
      lastHuaShu = currentY - lastY
      // console.log(lastHuaShu, that.data.enablePullDownRefresh)
      var text = that.data.text
      if (that.data.enablePullDownRefresh == 'true') {
        if (lastHuaShu > 0) {
          if (lastHuaShu > 15) {
            if (lastHuaShu * rpx < 220) {
              // console.log('lastHuaShu',lastHuaShu)
              if (that.data.code == 1){
                if (lastHuaShu * rpx>154){
                  animationZ.rotate(180).step()
                  text='释放刷新'
                }
                else{
                  animationZ.rotate(0).step()
                  text = '下拉刷新'
                }
              }
            }
            else {
              lastHuaShu = 220 * px
            }
          }
          that.setData({
            text: text,
            animationDataS: animationSX.translateY(lastHuaShu).step(),
            animationDataZ: animationZ.export(),
            catchP: true,
          })
        }
        else{
          that.setData({
            catchP: false,
          })
        }
      }


    },
    end: function (e) {
      var that = this
      var rpx = 750 / windowWidth
      var px = windowWidth / 750
      var animationSX = wx.createAnimation({
        transformOrigin: "50% 50%",
        duration: 500,
        timingFunction: "ease",
        delay: 0
      })
      var text = that.data.text
      var jiantou = that.data.jiantou
      var enablePullDownRefresh = that.data.enablePullDownRefresh
      // console.log(that.data.enablePullDownRefresh)
      if (lastHuaShu * rpx > 154) {
        // console.log(that.data.code)
        text = '刷新中...'
        jiantou=false
        enablePullDownRefresh = 'false'
        if(that.data.code==0){
          wx.showNavigationBarLoading()
          setIntervalK=null
          setIntervalK=setInterval(function(){
            var dianNum = that.data.dianNum
            if (dianNum==null){
              dianNum=0
            }
            else{
              if (dianNum > 3) {
                dianNum = 0
              }
              else{
                dianNum = dianNum + 1
              }
            }
            that.setData({
              dianNum: dianNum
            })
          },120)
        }
        animationSX.translateY(120 * px).step()
        that.triggerEvent('myevent', { onrefresh: true }, {})
        setTimeoutJ=null
        setTimeoutJ = setTimeout(function(){
           that.takeback()
        },20000)
        
      }
      else {
        that.triggerEvent('myevent', { onrefresh: false }, {})
       animationSX.translateY(0).step()
        enablePullDownRefresh = 'true'
        animationSX.top(0).step()
      }
      that.setData({
        animationDataS: animationSX.export(),
        enablePullDownRefresh: enablePullDownRefresh,
        text: text,
        jiantou: jiantou
      })
    },
    takeback:function(){
      var that = this
      var dianNum = that.data.dianNum
      var text = that.data.text
      var animationZ = wx.createAnimation({
        transformOrigin: "50% 50%",
        duration: 0,
        timingFunction: "ease",
        delay: 0
      })
      if(that.data.code==0){
        wx.hideNavigationBarLoading()
        clearInterval(setIntervalK)
        dianNum = null
      }
      if (that.data.code == 1) {
        // console.log('sda')
        animationZ.rotate(0).step()
        text='下拉刷新'
      }
      
      var rpx = 750 / windowWidth
      var px = windowWidth / 750
      var animationSX = wx.createAnimation({
        transformOrigin: "50% 50%",
        duration: 500,
        timingFunction: "ease",
        delay: 0
      })
      var text = that.data.text
      var enablePullDownRefresh = that.data.enablePullDownRefresh
      animationSX.translateY(0).step()
      that.setData({
        animationDataS: animationSX.export(),
        enablePullDownRefresh: 'true',
        dianNum: dianNum,
        animationDataZ: animationZ.export(),
        text: text,
      })
    },
  }
})
