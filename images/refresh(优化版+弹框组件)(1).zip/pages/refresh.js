// pages/ceshi.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  thatEvent: function (e) {
    var that = this
    that.refresh = that.selectComponent("#refresh")
    // console.log(e.detail.toupper)//到达顶部为true
    //console.log(e.detail.tolower)//到达底部为true
    // console.log(e.detail.scroll)//页面滚动距离
    /*********监听下拉刷新***************/
    if (e.detail.onrefresh == true) {
      setTimeout(function () {
        that.refresh.takeback()//关闭刷新
      }, 2000)
    }
    /***********************************/

    
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    /*********加载动作显示***************/
    app.showloadingMask({
      showloadingMask: 'true',
      showloadingTitle: '加载中...',
      // pathImg_xsw:'/component/img/loading_one.gif',
      duration: 1000,//自动关闭
      success: function (res) {
        //  console.log(res.path)//当前页面路径
      }
    })
    // 手动关闭
    // setTimeout(function(){
    //   app.showloadingMask({
    //     showloadingMask: 'false'//隐藏
    //   })
    // },3000)

    // 自定义showModal弹框

    app.showModal({
      title: '说明',
      content: '自定义的组件showModal自定义的组件showModal自定义的组件showModal自定义的组件showModal自定义的组件showModal自定义的组件showModal自定义的组件showModal自定义的组件showModal自定义的组件showModal自定义的组件showModal自定义的组件showModal自定义的组件showModal自定义的组件showModal自定义的组件showModal自定义的组件showModal自定义的组件showModal自定义的组件showModal自定义的组件showModal自定义的组件showModal自定义的组件showModal自定义的组件showModal',
      // showNoCancel:true,//是否不显示 取消按钮
      // pageNoBind:true,//是否不要页面点击关闭事件
      // transparent: true,// 是否背景透明
      frontColor: '#000000',//顶部文字颜色
      backgroundColor: '#fbe8b9',//顶部背景色
      success: function (res) {
        // console.log(res);
        if (res.confirm) {
          console.log('用户点击确定')
        } else if (res.cancel) {
          console.log('用户点击取消')
        } else if (res.change) {
          console.log('用户点击页面')
        }
      }
    })


    /***********************************/
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    clearInterval(setIntervalC)
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
function transformation(zhi) {
  var zhi = zhi.toString()
  if (zhi.length < 2) {
    zhi = '0' + zhi
  }
  else {
    zhi = zhi
  }
  return zhi
}